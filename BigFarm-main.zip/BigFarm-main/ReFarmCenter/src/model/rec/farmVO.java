package model.rec;

public class farmVO {
	private String farmName, farmState, farmDate, farmUse;
	private int farmNum, farmDongNum;
	public String getFarmName() {
		return farmName;
	}
	public void setFarmName(String farmName) {
		this.farmName = farmName;
	}
	public String getFarmState() {
		return farmState;
	}
	public void setFarmState(String farmState) {
		this.farmState = farmState;
	}
	public String getFarmDate() {
		return farmDate;
	}
	public void setFarmDate(String farmDate) {
		this.farmDate = farmDate;
	}
	public String getFarmUse() {
		return farmUse;
	}
	public void setFarmUse(String farmUse) {
		this.farmUse = farmUse;
	}
	public int getFarmNum() {
		return farmNum;
	}
	public void setFarmNum(int farmNum) {
		this.farmNum = farmNum;
	}
	public int getFarmDongNum() {
		return farmDongNum;
	}
	public void setFarmDongNum(int farmDongNum) {
		this.farmDongNum = farmDongNum;
	}

}
