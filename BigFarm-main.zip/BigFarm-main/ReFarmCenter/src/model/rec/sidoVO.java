package model.rec;

public class sidoVO {
	private int sidoBun;
	private String sidoName;
	private String sigunguName;
	private String dongName;
	private String pyoName;
	private String sicode;
	public int getSidoBun() {
		return sidoBun;
	}
	public void setSidoBun(int sidoBun) {
		this.sidoBun = sidoBun;
	}
	public String getSidoName() {
		return sidoName;
	}
	public void setSidoName(String sidoName) {
		this.sidoName = sidoName;
	}
	public String getSigunguName() {
		return sigunguName;
	}
	public void setSigunguName(String sigunguName) {
		this.sigunguName = sigunguName;
	}
	public String getDongName() {
		return dongName;
	}
	public void setDongName(String dongName) {
		this.dongName = dongName;
	}
	public String getPyoName() {
		return pyoName;
	}
	public void setPyoName(String pyoName) {
		this.pyoName = pyoName;
	}
	public String getSicode() {
		return sicode;
	}
	public void setSicode(String sicode) {
		this.sicode = sicode;
	}
	
}
